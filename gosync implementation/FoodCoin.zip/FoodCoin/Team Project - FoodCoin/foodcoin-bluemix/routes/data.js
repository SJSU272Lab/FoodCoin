/**
 * Created by Mak on 12/2/16.
 */

// var csvtojson= require('csvtojson');

function convert(req,res)
{

 console.log(req.body);
}

exports.convert=convert;