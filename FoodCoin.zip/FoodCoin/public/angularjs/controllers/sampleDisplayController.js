

index.controller('sampleDisplayController', function($scope, $http, $state, $anchorScroll,NgMap) {
	
});