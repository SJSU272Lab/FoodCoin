/**
 * Created by Mak on 12/5/16.
 */
index.controller("dashboard",['$scope','$http','$state' ,'$stateParams',function($scope,$http ,$state,$stateParams){


    console.log($stateParams);
}]);